// popup.js - UI logic for extension popup

const PRODUCTION_URL = 'https://www.maestraia.com'

async function getApiUrl() {
  const { apiUrl } = await chrome.storage.sync.get('apiUrl')
  return apiUrl || PRODUCTION_URL
}

// Inspect the active tab: are we on a Richmond course page, elsewhere on Richmond, or off-site?
// Returns { slug, onRichmond }.
function detectRichmondContext() {
  return new Promise((resolve) => {
    chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
      const url = tabs[0]?.url || ''
      const onRichmond = /richmondlp\.com/.test(url)
      const m = url.match(/richmondlp\.com\/courses\/([^/]+)/)
      resolve({ slug: m ? m[1] : null, onRichmond })
    })
  })
}

// First run: show the 3-step onboarding with the key form expanded.
// Configured: collapse the key form behind a summary so status + next action dominate.
function setConfiguredLayout(configured) {
  document.getElementById('onboarding').hidden = configured
  const wrap = document.getElementById('keyWrap')
  wrap.open = !configured
  document.getElementById('keySummary').textContent = configured
    ? 'Cambiar clave API'
    : 'Clave API'
}

document.addEventListener('DOMContentLoaded', async () => {
  const { apiKey } = await chrome.storage.sync.get('apiKey')
  if (apiKey) document.getElementById('apiKey').value = apiKey
  setConfiguredLayout(!!apiKey)

  if (apiKey) {
    const url = await getApiUrl()
    testConnection(apiKey, url)
  } else {
    // No key yet — surface any prior sync history instead of a blank box.
    await showLastSyncStatus()
  }

  document.getElementById('saveBtn').addEventListener('click', async () => {
    const key = document.getElementById('apiKey').value.trim()
    if (!key) { showMessage('Por favor ingresa una clave API', 'error'); return }
    const url = await getApiUrl()
    await chrome.storage.sync.set({ apiKey: key, apiUrl: url })
    showMessage('Configuración guardada', 'success')
    setConfiguredLayout(true)
    testConnection(key, url)
  })

  document.getElementById('testBtn').addEventListener('click', async () => {
    const key = document.getElementById('apiKey').value.trim()
    if (!key) { showMessage('Por favor ingresa una clave API primero', 'error'); return }
    const url = await getApiUrl()
    testConnection(key, url)
  })
})

function statusRow(label, value, opts = {}) {
  const row = document.createElement('div')
  row.className = 'status-item'
  const l = document.createElement('span')
  l.className = 'status-label'
  l.textContent = label
  if (opts.labelColor) l.style.color = opts.labelColor
  row.appendChild(l)
  if (value != null) {
    const v = document.createElement('span')
    v.className = 'status-value'
    v.textContent = value
    if (opts.valueColor) v.style.color = opts.valueColor
    row.appendChild(v)
  }
  return row
}

// Renders the one-tap group linking UI when teacher is on an unmapped Richmond course.
function buildMappingUI(classCode, unmappedGroups, apiUrl, onMapped) {
  const div = document.createElement('div')
  div.className = 'setup-guide'

  const title = document.createElement('p')
  title.className = 'setup-title'
  title.textContent = `Clase detectada: ${classCode}`
  div.appendChild(title)

  const label = document.createElement('p')
  label.className = 'setup-step'
  label.textContent = '¿A qué grupo de MaestraIA corresponde esta clase?'
  div.appendChild(label)

  const select = document.createElement('select')
  select.className = 'group-select'
  const defaultOpt = document.createElement('option')
  defaultOpt.value = ''
  defaultOpt.textContent = 'Selecciona tu grupo...'
  select.appendChild(defaultOpt)
  for (const g of unmappedGroups) {
    const opt = document.createElement('option')
    opt.value = g.id
    opt.textContent = g.name
    select.appendChild(opt)
  }
  div.appendChild(select)

  const btn = document.createElement('button')
  btn.className = 'link-btn'
  btn.textContent = 'Vincular este grupo'
  btn.onclick = async () => {
    const groupId = select.value
    if (!groupId) return
    btn.textContent = 'Vinculando...'
    btn.disabled = true

    const result = await new Promise((resolve) => {
      chrome.runtime.sendMessage(
        { type: 'MAP_GROUP', groupId, richmondSlug: classCode, apiUrl },
        (response) => { void chrome.runtime.lastError; resolve(response) }
      )
    })

    if (result?.ok) {
      onMapped() // re-run testConnection to reflect the new mapping
    } else {
      btn.textContent = 'Error — intenta de nuevo'
      btn.disabled = false
    }
  }
  div.appendChild(btn)

  return div
}

// Shown when connected but not on a Richmond course page.
// onRichmond=true → they're on Richmond but not inside a group; just guide them to open one.
function buildNotOnRichmondHint(onRichmond) {
  const div = document.createElement('div')
  div.className = 'setup-guide'

  const title = document.createElement('p')
  title.className = 'setup-title'
  title.textContent = onRichmond ? 'Abre un grupo para vincularlo' : 'Ve a Richmond'
  div.appendChild(title)

  const hint = document.createElement('p')
  hint.className = 'no-richmond-hint'
  hint.textContent = onRichmond
    ? 'Haz clic en el nombre de cualquiera de tus grupos en Richmond. Al entrar, vuelve a abrir esta extensión y podrás vincularlo con un clic.'
    : 'Inicia sesión en richmondlp.com, abre un grupo y vuelve a esta extensión para vincularlo.'
  div.appendChild(hint)

  if (!onRichmond) {
    const link = document.createElement('a')
    link.href = 'https://richmondlp.com'
    link.target = '_blank'
    link.className = 'setup-link'
    link.textContent = '→ Ir a Richmond'
    div.appendChild(link)
  }

  return div
}

// Returns a single status row summarizing the most recent sync, or null if none.
async function lastSyncRow() {
  const { lastSyncStatus, lastSyncTime, lastSyncGroup } =
    await chrome.storage.sync.get(['lastSyncStatus', 'lastSyncTime', 'lastSyncGroup'])
  if (!lastSyncTime) return null
  const when = formatRelativeTime(lastSyncTime)
  if (lastSyncStatus === 'ok') {
    return statusRow('Última sincronización', `${lastSyncGroup || ''} ${when}`.trim(), { valueColor: '#16a34a' })
  }
  return statusRow(`Último intento falló (${when})`, null, { labelColor: '#ef4444' })
}

const ERROR_COPY = {
  'HTTP 401': 'Verifica tu clave API',
  'HTTP 403': 'Sin autorización — verifica tu clave API',
  'HTTP 500': 'Error del servidor — reintenta en un momento',
  'HTTP 503': 'Servicio no disponible — reintenta en un momento',
  max_retries: 'No se pudo conectar tras 3 intentos',
  no_key: 'Configura tu clave API primero',
}

async function showLastSyncStatus() {
  const { lastSyncStatus, lastSyncTime, lastSyncGroup, lastSyncError } =
    await chrome.storage.sync.get(['lastSyncStatus', 'lastSyncTime', 'lastSyncGroup', 'lastSyncError'])
  if (!lastSyncTime) return

  const when = formatRelativeTime(lastSyncTime)
  const statusDetails = document.getElementById('statusDetails')

  if (lastSyncStatus === 'ok') {
    const rows = [statusRow('Última sincronización', when, { valueColor: '#16a34a' })]
    if (lastSyncGroup) rows.push(statusRow('Grupo', lastSyncGroup))
    statusDetails.replaceChildren(...rows)
  } else if (lastSyncStatus === 'error') {
    document.getElementById('statusBox').className = 'status error'
    const humanError =
      ERROR_COPY[lastSyncError] ||
      (lastSyncError && lastSyncError.startsWith('HTTP 5') ? 'Error del servidor' : lastSyncError || 'Error desconocido')
    const rows = [
      statusRow(`Error al sincronizar (${when})`, null, { labelColor: '#ef4444' }),
      statusRow(humanError, null),
    ]

    // Retry button — only shown when there's a stored payload to retry
    const { lastFailedSync } = await chrome.storage.local.get('lastFailedSync')
    if (lastFailedSync) {
      const retryBtn = document.createElement('button')
      retryBtn.className = 'link-btn'
      retryBtn.style.marginTop = '8px'
      retryBtn.textContent = 'Reintentar sincronización'
      retryBtn.onclick = async () => {
        retryBtn.textContent = 'Reintentando…'
        retryBtn.disabled = true
        const result = await new Promise((resolve) => {
          chrome.runtime.sendMessage({ type: 'RETRY_SYNC' }, (response) => {
            void chrome.runtime.lastError
            resolve(response)
          })
        })
        if (result?.ok) {
          retryBtn.textContent = '¡Sincronizado!'
          retryBtn.style.background = '#22c55e'
          retryBtn.style.color = '#fff'
        } else {
          const errMsg = ERROR_COPY[result?.error] || 'No se pudo — revisa tu conexión'
          retryBtn.textContent = errMsg
          retryBtn.disabled = false
        }
      }

      const wrapper = document.createElement('div')
      wrapper.replaceChildren(...rows, retryBtn)
      statusDetails.replaceChildren(wrapper)
    } else {
      statusDetails.replaceChildren(...rows)
    }
  }
}

async function testConnection(apiKey, apiUrl) {
  const statusBox = document.getElementById('statusBox')
  const statusDot = document.getElementById('statusDot')
  const statusTitle = document.getElementById('statusTitle')
  const statusDetails = document.getElementById('statusDetails')

  statusBox.className = 'status'
  statusDot.className = 'status-dot gray'
  statusTitle.textContent = 'Conectando...'
  statusDetails.replaceChildren()

  const result = await new Promise((resolve) => {
    chrome.runtime.sendMessage({ type: 'FETCH_GROUPS', apiKey, apiUrl }, (response) => {
      if (chrome.runtime.lastError) resolve({ ok: false, error: 'service_worker_inactive' })
      else resolve(response)
    })
  })

  if (!result?.ok) {
    statusBox.className = 'status error'
    statusDot.className = 'status-dot red'
    statusTitle.textContent = 'Error de conexión'
    let msg = 'No se pudo conectar al servidor'
    if (result?.statusCode === 401) {
      msg = 'Clave API inválida o revocada — genera una nueva en MaestraIA'
      // Reopen the key form so the fix is one paste away.
      document.getElementById('keyWrap').open = true
    }
    statusDetails.replaceChildren(statusRow(msg, null, { labelColor: '#ef4444' }))
    return
  }

  const data = result.data
  const mappedGroups = data.mappedGroups ?? Object.keys(data.groupMap ?? {}).length
  const unmappedGroups = data.unmappedGroups ?? []
  const { slug: classCode, onRichmond } = await detectRichmondContext()
  const currentCourseIsMapped = classCode && data.groupMap && data.groupMap[classCode]

  statusBox.className = 'status connected'
  statusDot.className = 'status-dot green'
  statusTitle.textContent = data.teacherName ? `✓ ${data.teacherName}` : '✓ Conectada'

  const nodes = []
  let shownCourseSync = false

  if (currentCourseIsMapped) {
    // Once this group has synced at least once, show "Listo" instead of the how-to.
    const { syncTimes } = await chrome.storage.sync.get('syncTimes')
    const syncedAt = syncTimes?.[data.groupMap[classCode]]
    if (syncedAt) {
      nodes.push(statusRow('✓ Listo', `Sincronizado ${formatRelativeTime(syncedAt)}`, { valueColor: '#16a34a' }))
      shownCourseSync = true
    } else {
      nodes.push(statusRow('✓ Grupo vinculado', classCode, { valueColor: '#16a34a' }))
      nodes.push(statusRow('Abre Markbook → Scores para sincronizar', null))
    }
  } else if (classCode && unmappedGroups.length > 0) {
    // On an unmapped Richmond course → one-tap picker
    nodes.push(buildMappingUI(classCode, unmappedGroups, apiUrl, () => testConnection(apiKey, apiUrl)))
  } else if (classCode && mappedGroups === 0) {
    // On a Richmond course but teacher has no MaestraIA groups yet
    nodes.push(statusRow('Crea un grupo en MaestraIA primero', null, { labelColor: '#f59e0b' }))
  } else if (classCode) {
    // On a Richmond course, not mapped, but all groups already linked elsewhere
    nodes.push(statusRow('Esta clase no coincide con tus grupos', null, { labelColor: '#f59e0b' }))
    nodes.push(statusRow('Todos tus grupos ya están vinculados a otras clases', null))
  } else {
    // Not inside a course page (Richmond dashboard or off-site)
    if (mappedGroups > 0) nodes.push(statusRow('Grupos vinculados', mappedGroups, { valueColor: '#16a34a' }))
    nodes.push(buildNotOnRichmondHint(onRichmond))
  }

  // Surface the last sync result (unless the course-specific "Listo" row already did).
  if (!shownCourseSync) {
    const lastRow = await lastSyncRow()
    if (lastRow) nodes.push(lastRow)
  }

  statusDetails.replaceChildren(...nodes)

  // Reload mappings in the active Richmond tab
  chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
    if (!tabs[0]) return
    chrome.tabs.sendMessage(tabs[0].id, { type: 'RELOAD_MAPPINGS' }, () => { void chrome.runtime.lastError })
  })
}

function formatRelativeTime(isoString) {
  const diffMs = Date.now() - new Date(isoString).getTime()
  const diffMin = Math.floor(diffMs / 60000)
  if (diffMin < 1) return 'ahora mismo'
  if (diffMin < 60) return `hace ${diffMin} min`
  const diffHr = Math.floor(diffMin / 60)
  if (diffHr < 24) return `hace ${diffHr}h`
  return `hace ${Math.floor(diffHr / 24)} días`
}

function showMessage(text, type) {
  const msg = document.getElementById('saveMsg')
  msg.textContent = text
  msg.className = `message ${type}`
  if (type === 'success') setTimeout(() => { msg.className = 'message' }, 3000)
}
